joelRFMPackage
-----------------------

This baller package provides the most amazing functionality of all time 